import * as React from 'react'
import { useEffect, useState } from 'react';
import { childControlsJson, controlsJson, Row, safeJsonParse } from "./SubgridComponent";
import { Button, Text, DrawerFooter, DrawerHeader, DrawerHeaderTitle, Field, OverlayDrawer } from '@fluentui/react-components';
import NotificationComponent from './NotificationComponent';
import RenderFieldComponent from './RenderFieldComponent';
import { IInputs } from './generated/ManifestTypes';
import { bundleIcon, SaveFilled, SaveRegular } from '@fluentui/react-icons';

interface FormComponentProps {
    context: ComponentFramework.Context<IInputs>;
    isDisable: boolean;
    json: controlsJson;
    callback: (data: Row) => void;
    fieldInput: string;
}
const SaveIcon = bundleIcon(SaveFilled, SaveRegular);

function FormComponent({ context, isDisable, json, callback, fieldInput }: FormComponentProps) {
    const [rowData, setRowData] = useState<Row>({});
    const [messageNoti, setMessageNoti] = useState<string>("");
    const [visibleNoti, setVisibleNoti] = useState<boolean>(false);

    useEffect(() => {
        if (fieldInput) {
            const arr = safeJsonParse<Row[]>(fieldInput);
            if (Array.isArray(arr) && arr.length > 0) {
                setRowData(arr[0]);
            } else {
                setRowData({});
            }
        }
    }, [fieldInput]);

    return (

        <>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #ccc" }}>
                <Text style={{ padding: 10, fontSize: "16px", fontWeight: "600", }}>{json.label.toUpperCase()}</Text>
                <div style={{ marginBottom: "5px", display: "flex", justifyContent: "flex-end" }}>
                    <Button icon={<SaveIcon />} onClick={() => callback(rowData)} style={{ border: "none", padding: 10 }}>Save</Button>
                </div>
            </div>
            <div style={{ padding: 10 }}>
                {
                    json.controls.map((key, index) => {
                        return (
                            <div key={index} style={{ marginBottom: '10px' }}>
                                <Field label={key.label}>
                                    <RenderFieldComponent
                                        key={key.name}
                                        objControl={json.controls[index]}
                                        value={rowData[key.name]}
                                        onChange={(value) => {
                                            if (json.controls[index].type == "datetime")
                                                setRowData({ ...rowData, [key.name]: value ? new Date(value).toLocaleString() : "" })
                                            else
                                                setRowData({ ...rowData, [key.name]: value })
                                        }}
                                        context={context}
                                        isDisable={isDisable}
                                    />
                                </Field>
                            </div>
                        )
                    })
                }
                <NotificationComponent message={messageNoti} _visible={visibleNoti} _setVisible={setVisibleNoti} setMessage={setMessageNoti} />
            </div>
        </>
    )
}

export default FormComponent