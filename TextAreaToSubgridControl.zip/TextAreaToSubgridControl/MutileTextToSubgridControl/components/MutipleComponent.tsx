import { Text, Textarea } from '@fluentui/react-components'
import * as React from 'react'

interface MutipleComponentProps {
    value: string;
    onChange: (e: string) => void;
    isDisable: boolean;
}

function MutipleComponent({ onChange, value, isDisable }: MutipleComponentProps) {
    const [data, setData] = React.useState<string>(value ?? "");

    React.useEffect(() => {
        setData(value);
    }, [value])

    return (
        <>
            {
                !isDisable ?
                    <Textarea value={data} onChange={(_, data) => onChange(data.value)} style={{ width: "100%" }} size='large' />
                    :
                    <Text>{data}</Text>
            }
        </>
    )
}

export default MutipleComponent