import { Input, Text } from '@fluentui/react-components'
import * as React from 'react'

interface NumberComponentProps {
    value: string;
    onChange: (e: string) => void;
    isDisable: boolean;
}

function NumberComponent({ onChange, value, isDisable }: NumberComponentProps) {
    const [data, setData] = React.useState<string>(value ?? "");

    React.useEffect(() => {
        setData(value);
    }, [value])

    return (
        <>
            {
                !isDisable ?
                    <Input type={"number"} value={data} onChange={(_, data) => onChange(data.value)} style={{ width: "100%" }} />
                    :
                    <Text>{data}</Text>
            }
        </>
    )
}

export default NumberComponent