import { Input, makeStyles, Text } from '@fluentui/react-components'
import * as React from 'react'

interface TextComponentProps {
    value: string;
    onChange: (e: string) => void;
    isDisable: boolean;
}

const useStyles = makeStyles({
    inputCustom: {
        width: "100%",
    },
})

function TextComponent({ onChange, value, isDisable }: TextComponentProps) {
    const styles = useStyles();
    const [data, setData] = React.useState<string>(value ?? "");

    React.useEffect(() => {
        setData(value);
    }, [value])

    return (
        <>
            {
                !isDisable ?
                    <Input type={"text"} value={data} onChange={(_, data) => onChange(data.value)} className={styles.inputCustom} />
                    :
                    <Text>{data}</Text>
            }
        </>
    )
}

export default TextComponent