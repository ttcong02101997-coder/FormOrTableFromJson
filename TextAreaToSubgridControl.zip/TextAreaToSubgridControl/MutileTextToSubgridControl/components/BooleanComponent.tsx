import { Switch, Text } from '@fluentui/react-components';
import * as React from 'react'

interface BooleanComponentProps {
    value: string;
    onChange: (e: string) => void;
    isDisable: boolean;
}

function BooleanComponent({ onChange, value, isDisable }: BooleanComponentProps) {
    const [checked, setChecked] = React.useState(false);

    const _onChange = React.useCallback(
        (ev: React.ChangeEvent<HTMLInputElement>) => {
            setChecked(ev.currentTarget.checked);
        },
        [setChecked]
    );

    React.useEffect(() => {
        if (value != "" && value != undefined)
            setChecked(true);
    }, [value])

    React.useEffect(() => {
        let fakeEvent = "";
        if (checked) {
            fakeEvent = "true";
        }
        else {
            fakeEvent = "";
        }
        onChange(fakeEvent);
    }, [checked])

    return (
        <>
            {
                !isDisable ?
                    <Switch
                        checked={checked}
                        onChange={_onChange}
                    />
                    :
                    <Text>{value != "" ? "Yes" : "No"}</Text>
            }
        </>
    )
}

export default BooleanComponent