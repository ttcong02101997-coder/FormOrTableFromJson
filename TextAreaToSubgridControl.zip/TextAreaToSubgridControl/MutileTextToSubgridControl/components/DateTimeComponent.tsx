import * as React from "react";
import { makeStyles, Text } from "@fluentui/react-components";
import { DatePicker, DatePickerProps } from "@fluentui/react-datepicker-compat";
import {
    TimePicker,
    TimePickerProps,
    formatDateToTimeString,
} from "@fluentui/react-timepicker-compat";

const useStyles = makeStyles({
    root: {
        display: "grid",
        columnGap: "20px",
        gridTemplateColumns: "repeat(2, 1fr)",
        marginBottom: "10px",
    },
});

interface DateTimeComponentProps {
    value: string;
    onChange: (e: string) => void;
    isDisable: boolean;
}

const DateTimeComponent = ({ onChange, value, isDisable }: DateTimeComponentProps) => {
    const styles = useStyles();
    const [selectedDate, setSelectedDate] = React.useState<Date | null | undefined>(null);
    const [selectedTime, setSelectedTime] = React.useState<Date | null>(null);
    const [timePickerValue, setTimePickerValue] = React.useState<string>(selectedTime ? formatDateToTimeString(selectedTime) : "");


    React.useEffect(() => {
        if (value) {
            const date = new Date(value);
            setSelectedDate(date);
            setSelectedTime(
                new Date(
                    date.getFullYear(),
                    date.getMonth(),
                    date.getDate(),
                    date.getHours(),
                    date.getMinutes()
                )
            );
            setTimePickerValue(formatDateToTimeString(date));
        }
    }, [value])

    const onSelectDate: DatePickerProps["onSelectDate"] = (date) => {
        setSelectedDate(date);
        if (date && selectedTime) {
            setSelectedTime(
                new Date(
                    date.getFullYear(),
                    date.getMonth(),
                    date.getDate(),
                    selectedTime.getHours(),
                    selectedTime.getMinutes()
                )
            );
        }
    };

    const onTimeChange: TimePickerProps["onTimeChange"] = (_ev, data) => {
        setSelectedTime(data.selectedTime);
        setTimePickerValue(data.selectedTimeText ?? "");
    };
    const onTimePickerInput = (ev: React.ChangeEvent<HTMLInputElement>) => {
        setTimePickerValue(ev.target.value);
    };

    React.useEffect(() => {
        const newVal = selectedDate && (selectedTime ? selectedTime.toString() : selectedDate.toString());

        onChange(newVal ?? "");
    }, [selectedDate, selectedTime])

    return (
        <>
            {
                !isDisable ?
                    <div className={styles.root}>
                        <DatePicker
                            value={selectedDate}
                            onSelectDate={onSelectDate}
                            inlinePopup={true}
                            formatDate={(date) =>
                                date
                                    ? `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`
                                    : ""
                            }
                        />
                        <TimePicker
                            freeform
                            dateAnchor={selectedDate ?? undefined}
                            selectedTime={selectedTime}
                            onTimeChange={onTimeChange}
                            value={timePickerValue}
                            onInput={onTimePickerInput}
                            inlinePopup={true}
                        />
                    </div>
                    :
                    <Text>{value}</Text>
            }
        </>
    );
};

export default DateTimeComponent;