import { Text } from '@fluentui/react-components';
import { DatePicker } from '@fluentui/react-datepicker-compat';
import * as React from 'react'
import { useEffect, useState } from 'react';

interface DateComponentProps {
    value: string;
    onChange: (e: string) => void;
    isDisable: boolean;
}

const DateComponent = ({ onChange, value, isDisable }: DateComponentProps) => {
    const [_date, _setDate] = useState<Date | null | undefined>(null);

    useEffect(() => {
        if (value)
            _setDate(new Date(value));
    }, [value])

    return (
        <>
            {
                !isDisable ?
                    <DatePicker
                        style={{ width: "100%" }}
                        inlinePopup={true}
                        value={_date}
                        onSelectDate={(date) => {
                            const newVal = date ? date.toLocaleDateString() : "";
                            onChange(newVal);
                        }}
                        formatDate={(date) =>
                            date
                                ? `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`
                                : ""
                        }
                    />
                    :
                    <Text>{value}</Text>
            }
        </>
    )
}

export default DateComponent