import { Dropdown, Text, Option } from '@fluentui/react-components';
import * as React from 'react'
import { childItemsJson } from '../SubgridComponent';

interface OptionsetComponentProps {
    value: string;
    onChange: (e: string) => void;
    labels: childItemsJson[];
    isDisable: boolean;
}

function OptionsetComponent({ isDisable, labels, onChange, value }: OptionsetComponentProps) {
    const [_item, _setItem] = React.useState<childItemsJson>();


    React.useEffect(() => {
        if (value)
            _setItem(JSON.parse(value) as childItemsJson);
    }, [value])

    const onOptionClick = (item: childItemsJson) => {
        onChange(item ? JSON.stringify(item) : "");
    }

    return (
        <>
            {
                !isDisable ?
                    <>
                        <Dropdown selectedOptions={[_item?.value ?? '']} value={_item?.label ?? ''}>
                            {
                                labels.map((item, index) => {
                                    return (
                                        <Option key={index} value={item.value} onClick={() => { onOptionClick(item) }}>
                                            {item.label}
                                        </Option>
                                    )
                                })
                            }
                        </Dropdown>
                    </>
                    :
                    <Text>{_item?.label}</Text>
            }
        </>
    )
}

export default OptionsetComponent