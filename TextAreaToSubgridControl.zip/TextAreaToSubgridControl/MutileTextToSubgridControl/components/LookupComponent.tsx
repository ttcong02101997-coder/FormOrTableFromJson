import * as React from 'react'
import { Text, Dropdown, Input, InteractionTag, InteractionTagPrimary, InteractionTagSecondary, makeStyles, Option, Tag, TagGroup, Button } from '@fluentui/react-components';
import { IInputs } from '../generated/ManifestTypes';
import { Dismiss12Regular, Open24Regular, Search24Regular } from '@fluentui/react-icons';


interface LookupComponentProps {
    value: string;
    onChange: (e: string) => void;
    entityName: string;
    context: ComponentFramework.Context<IInputs>;
    isDisable: boolean;
    setVisible?: (v: boolean) => void;
}

export interface LookupEntity {
    id: string;
    name: string;
    entityType: string;
};

const useStyles = makeStyles({
    customBtn: {
        border: "none",
        backgroundColor: "rgb(235, 243, 252)",
        ":hover": {
            backgroundColor: "rgb(207, 228, 250)",
        },
        color: "rgb(17, 94, 163)",
        fontSize: "14px"
    },
    customText: {
        color: "rgb(17, 94, 163)",
        fontSize: "14px",
        cursor: "pointer",
        width: "100%",
        padding: "5px"
    },
});

function LookupComponent({ onChange, value, entityName, context, isDisable, setVisible }: LookupComponentProps) {
    const styles = useStyles();
    const [_search, _setSearch] = React.useState<string>("");
    const [valueLookup, setValueLookup] = React.useState<LookupEntity | undefined>();

    React.useEffect(() => {
        if (value != "" && value != undefined) {
            const data: LookupEntity = JSON.parse(value) as LookupEntity;
            setValueLookup(data);
        }
        else {
            setValueLookup(undefined);
        }
    }, [value])

    React.useEffect(() => {
        onChange(valueLookup ? JSON.stringify(valueLookup) : "");
    }, [valueLookup])

    const viewLookup = () => {
        if (valueLookup) {
            void window.Xrm.Navigation.navigateTo({
                pageType: "entityrecord",
                entityName: valueLookup.entityType,
                entityId: valueLookup.id
            }, {
                target: 2,
                position: 1,
                width: { value: 80, unit: "%" },
                height: { value: 70, unit: "%" }
            });
        }
    }

    const openLookupDialog = async () => {
        if (setVisible)
            setVisible(false);
        const result = await context.utils.lookupObjects({
            allowMultiSelect: false,
            defaultEntityType: entityName,
            entityTypes: [`${entityName}`],
            viewIds: [],
        });

        if (result && result.length > 0) {
            onChange(result[0] ? JSON.stringify(result[0]) : "");
        }
        if (setVisible)
            setVisible(true);
    };

    return (
        <>
            {
                !isDisable ?
                    <>
                        <div style={{
                            padding: "5px",
                            borderRadius: "5px",
                            display: "flex",
                            alignItems: "center",
                            position: "relative",
                            justifyContent: "space-between",
                            border: "1px solid #ccc"
                        }}>
                            <TagGroup>
                                {valueLookup?.id ? (
                                    <InteractionTag value={valueLookup.id} key={valueLookup.id}>
                                        <InteractionTagPrimary
                                            hasSecondaryAction
                                            className={styles.customBtn}
                                            onClick={viewLookup}
                                        >
                                            <span style={{ textDecoration: "underline" }}>{valueLookup.name}</span>
                                        </InteractionTagPrimary>
                                        <InteractionTagSecondary
                                            onClick={() => {
                                                setValueLookup(undefined);
                                            }}
                                            className={styles.customBtn}
                                            style={{ border: "none" }}
                                        />
                                    </InteractionTag>
                                )
                                    : null
                                }
                            </TagGroup>
                            <Button
                                appearance="transparent"
                                icon={<Search24Regular />}
                                onClick={() => void openLookupDialog()}
                                style={{
                                    padding: "2px",
                                    minWidth: "24px",
                                    height: "24px",
                                    marginLeft: "5px"
                                }}
                            />
                        </div>
                    </>
                    :
                    <>
                        {
                            valueLookup ?
                                <Text
                                    className={styles.customText}
                                    onClick={viewLookup}
                                >
                                    <span style={{ textDecoration: "underline" }}>{valueLookup?.name}</span>
                                </Text>
                                :
                                null
                        }

                    </>
            }
        </>
    )
}
export default LookupComponent