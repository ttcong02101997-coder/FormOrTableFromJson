import { Button, createTableColumn, DataGrid, DataGridBody, DataGridCell, DataGridHeader, DataGridHeaderCell, DataGridRow, FluentProvider, TableColumnDefinition, TableRowId, webLightTheme, Text } from '@fluentui/react-components';
import * as React from 'react'
import { useEffect, useState } from 'react';
import PopupRowComponent from './PopupRowComponent';
import { AddFilled, bundleIcon, DeleteFilled, DeleteRegular, AddRegular, ArrowExportFilled, ArrowExportRegular, SaveFilled, SaveRegular } from '@fluentui/react-icons';
import ConfirmPopupComponent from './ConfirmPopupComponent';
import { read, utils, write, writeFile } from "xlsx";
import { IInputs } from './generated/ManifestTypes';
import RenderFieldComponent from './RenderFieldComponent';
import { LookupEntity } from './components/LookupComponent';
import FormComponent from './FormComponent';

export interface ISubgridComponentProps {
  fieldInput: string;
  fieldJsons: string;
  context: ComponentFramework.Context<IInputs>;
  callback: (e: string) => void;
}

export type Row = Record<string, string>;

const AddIcon = bundleIcon(AddFilled, AddRegular);
const DeleteIcon = bundleIcon(DeleteFilled, DeleteRegular);
const ExportIcon = bundleIcon(ArrowExportFilled, ArrowExportRegular);

const removeEmptyRows = (rows: Row[]): Row[] => {
  return rows.filter(row =>
    Object.values(row).some(v => v !== "" && v !== null && v !== undefined)
  );
}

export function safeJsonParse<T>(value: string): T | undefined {
  try {
    return JSON.parse(value) as T;
  } catch {
    return undefined;
  }
}

function getColName(k: string, controls: childControlsJson[]) {
  return controls.find(e => e.name == k)?.label;
}

export function exportJsonToXlsx(
  rows: Row[],
  controls: childControlsJson[],
  filename = "data.xlsx",
) {
  const clean: Row[] = removeEmptyRows(rows);

  const cols = controls.map(c => c.label);
  const colsName = controls.map(c => c.name);

  if (colsName.length === 0 && clean.length === 0) {
    const wb = utils.book_new();
    utils.book_append_sheet(wb, utils.aoa_to_sheet([]), "Sheet1");
    writeFile(wb, filename);
    return;
  }

  const normalized: Row[] = clean.map(r => {
    return Object.fromEntries(
      colsName.map((k, i) => {
        const control = controls[i];
        if (control.type === "lookup") {
          const parsed = safeJsonParse<LookupEntity>(r[k]);
          return [getColName(k, controls) ?? k, parsed?.name ?? ""];
        } else if (control.type === "optionset") {
          const parsed = safeJsonParse<childItemsJson>(r[k]);
          return [getColName(k, controls) ?? k, parsed?.label ?? ""];
        } else {
          return [getColName(k, controls) ?? k, r?.[k] ?? ""];
        }
      })
    );
  });

  const ws =
    normalized.length > 0
      ? utils.json_to_sheet(normalized, { header: cols })
      : utils.aoa_to_sheet([cols]);

  const colWidths = cols.map(h => ({ wch: Math.max(10, String(h).length + 2) }));
  (ws)["!cols"] = colWidths;

  const wb = utils.book_new();
  utils.book_append_sheet(wb, ws, "Sheet1");
  writeFile(wb, filename);
}

export interface controlsJson {
  controls: childControlsJson[];
  delete: boolean;
  label: string;
  subgrid: boolean;
}

export interface childControlsJson {
  name: string;
  label: string;
  type: string;
  entityType?: string;
  items?: childItemsJson[];
}

export interface childItemsJson {
  label: string;
  value: string;
}

function SubgridComponent({ fieldInput, fieldJsons, callback, context }: ISubgridComponentProps) {
  const [rows, setRows] = useState<Row[]>([]);
  const [columns, setColumns] = useState<TableColumnDefinition<Row>[]>([]);
  const [visible, setVisible] = useState<boolean>(false);
  const [visibleNoti, setVisibleNoti] = useState<boolean>(false);
  const [itemSelected, setItemSelected] = useState<Row | null>(null);
  const [selectedRows, setSelectedRows] = React.useState<Set<TableRowId>>(() => new Set<TableRowId>());
  const [indexSelect, setIndexSelect] = useState<number>(-1);
  const [messageNoti, setMessageNoti] = useState<string>("");
  const [_json, _setJson] = useState<controlsJson>();

  useEffect(() => {
    if (fieldJsons) {
      const jsonParse = JSON.parse(fieldJsons) as controlsJson;
      _setJson(jsonParse);
      if (fieldInput) {
        if (fieldInput != "val") {
          setRows(JSON.parse(fieldInput) as React.SetStateAction<Row[]>);
        }
      }
    }
  }, [fieldInput]);

  useEffect(() => {
    const columnKeys = _json?.controls as [childControlsJson];
    if (columnKeys) {
      const _columns = columnKeys.map((k: childControlsJson, i) => {
        return createTableColumn<Row>({
          columnId: k.name,
          renderHeaderCell: () => k.label,
          renderCell: item => <RenderFieldComponent
            context={context}
            key={k.name}
            isDisable={true}
            value={item[k.name]}
            objControl={_json?.controls[i]}
            onChange={() => console.log()}
          />,
          compare: (a, b) => String(a[k.name] ?? '').localeCompare(String(b[k.name] ?? '')),
        })
      }
      );
      setColumns(_columns);
    }
  }, [rows, _json]);

  const onDeleteRow = () => {
    let arrayRows: Row[] = rows;
    const remove = selectedRows;
    const next = arrayRows.filter((_, i) => !remove.has(i));
    arrayRows = next;
    const cleaned = removeEmptyRows(arrayRows);
    if (cleaned.length > 0) {
      setRows(cleaned);
      callback(JSON.stringify(cleaned));
      setSelectedRows(new Set());
    }
    else {
      setRows([]);
      callback("");
      setSelectedRows(new Set());
    }
  }

  const onAddRow = () => {
    setVisible(true);
  }

  const onDoubleClick = (e: React.MouseEvent, item: Row, rowId: TableRowId) => {
    const index = Number(rowId.toString());
    setIndexSelect(index);
    setItemSelected(item);
    setVisible(true);
  }

  const inputRow = (data: Row) => {
    if (Object.keys(data).length > 0) {
      let arrayRows: Row[] = rows;
      let arr = [];
      if (indexSelect != -1) {
        arr = [
          ...arrayRows.slice(0, indexSelect),
          data,
          ...arrayRows.slice(indexSelect + 1)
        ];
      }
      else {
        arr = arrayRows;
        arr.push(data);
      }

      arrayRows = arr;
      setRows(arrayRows);
      callback(JSON.stringify(arrayRows));
    }
    setSelectedRows(new Set());
    setIndexSelect(-1);
  }

  return (
    <FluentProvider theme={webLightTheme} style={{ width: "100%", padding: 5 }}>
      {
        _json?.subgrid ?

          <>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #ccc" }}>
              <Text style={{ padding: 10, fontSize: "16px", fontWeight: "600", }}>{_json?.label.toUpperCase()}</Text>
              <div style={{ marginBottom: "5px", display: "flex", justifyContent: "flex-end" }}>
                <Button icon={<AddIcon />} onClick={onAddRow} style={{ border: "none", padding: 10 }}>Add</Button>
                {
                  _json?.delete && selectedRows.size > 0 ?
                    <Button icon={<DeleteIcon />} style={{ border: "none", padding: 10 }} onClick={() => { setVisibleNoti(true); setMessageNoti("Do you want delete row?"); }}>Delete</Button>
                    : null
                }
                {
                  fieldInput.length > 0 ?
                    <Button icon={<ExportIcon />} style={{ border: "none", padding: 10 }} onClick={() => { exportJsonToXlsx(rows, _json?.controls ?? []) }}>Export</Button>
                    : null
                }
              </div>
            </div>
            <DataGrid
              items={rows}
              columns={columns}
              sortable
              resizableColumns
              selectionMode='multiselect'
              onSelectionChange={(e, data) => {
                const _selectedRows = data.selectedItems;
                setSelectedRows(_selectedRows);
              }}
              selectedItems={selectedRows}
            >
              <DataGridHeader style={{ padding: 10, paddingTop: 5 }}>
                <DataGridRow style={{ borderBottom: "1px solid #ccc", padding: 5 }}>
                  {({ renderHeaderCell }) =>
                    <DataGridHeaderCell style={{ fontWeight: "bold", textAlign: "center" }}>{renderHeaderCell()}</DataGridHeaderCell>
                  }
                </DataGridRow>
              </DataGridHeader>
              <DataGridBody<Row>>
                {({ item, rowId }) => {
                  const isEmpty = Object.getOwnPropertyNames(item).every(
                    key => item[key] == undefined || item[key] == null || item[key] == ""
                  );
                  if (!isEmpty)
                    return (
                      <DataGridRow
                        key={rowId}
                        style={{ borderBottom: "1px solid #ccc", paddingRight: 15, paddingLeft: 15 }}
                        onDoubleClick={(e: React.MouseEvent) => { onDoubleClick(e, item, rowId) }}
                      >
                        {({ renderCell }) => <DataGridCell style={{ fontWeight: "normal" }}>{renderCell(item)}</DataGridCell>}
                      </DataGridRow>
                    )
                }}
              </DataGridBody>
            </DataGrid>
          </>
          :
          <>
            {_json && (
              <FormComponent
                context={context}
                json={_json}
                isDisable={false}
                callback={(data: Row) => {
                  const arr = [data];
                  setRows(arr);
                  callback(JSON.stringify(arr));
                }}
                fieldInput={fieldInput}
              />
            )}
          </>
      }

      <PopupRowComponent
        itemSelected={itemSelected}
        visible={visible}
        setItemSelected={setItemSelected}
        setVisible={setVisible}
        callback={(data: Row) => {
          inputRow(data);
        }}
        context={context}
        isDisable={false}
        controls={_json?.controls ?? []}
      />

      <ConfirmPopupComponent
        _visible={visibleNoti}
        _setVisible={setVisibleNoti}
        callback={(type) => {
          setMessageNoti("");
          if (type == "done") {
            onDeleteRow();
          }
        }}
        message={messageNoti}
      />
    </FluentProvider>
  )
}

export default SubgridComponent