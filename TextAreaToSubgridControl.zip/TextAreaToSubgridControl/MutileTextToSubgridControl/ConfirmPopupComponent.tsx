import { Button, Dialog, DialogActions, DialogBody, DialogContent, DialogSurface, DialogTitle } from '@fluentui/react-components';
import * as React from 'react'
import { useEffect, useState } from 'react';

interface ConfirmPopupComponentProps {
    _visible: boolean;
    message: string;
    _setVisible: (visible: boolean) => void;
    callback: (type: string) => void;
}


function ConfirmPopupComponent({ _setVisible, _visible, message, callback }: ConfirmPopupComponentProps) {
    const [visible, setVisible] = useState<boolean>(false);

    useEffect(() => {
        setVisible(_visible);
    }, [_visible]);

    const onClose = () => {
        setVisible(false);
        _setVisible(false);
        callback("close");
    }

    const onDone = () => {
        setVisible(false);
        _setVisible(false);
        callback("done");
    }

    return (
        <Dialog open={visible}>
            <DialogSurface>
                <DialogBody>
                    <DialogTitle>Notification</DialogTitle>
                    <DialogContent>
                        {message}
                    </DialogContent>
                    <DialogActions>
                        <Button appearance="primary" onClick={onDone}>OK</Button>
                        <Button appearance="outline" onClick={onClose}>Close</Button>
                    </DialogActions>
                </DialogBody>
            </DialogSurface>
        </Dialog >
    )
}

export default ConfirmPopupComponent