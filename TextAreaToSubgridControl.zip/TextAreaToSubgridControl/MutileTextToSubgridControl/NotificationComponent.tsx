import { Button, Dialog, DialogActions, DialogBody, DialogContent, DialogSurface, DialogTitle } from '@fluentui/react-components'
import * as React from 'react'
import { useEffect, useState } from 'react';

interface NotificationComponentProps {
    _visible: boolean;
    message: string;
    _setVisible: (visible: boolean) => void;
    setMessage: (message: string) => void;
}

function NotificationComponent({ message, _visible, _setVisible, setMessage }: NotificationComponentProps) {
    const [visible, setVisible] = useState<boolean>(false);

    useEffect(() => {
        setVisible(_visible);
    }, [_visible]);

    const onClose = () => {
        setVisible(false);
        _setVisible(false);
        setMessage("")
    }

    return (
        <Dialog open={visible}>
            <DialogSurface>
                <DialogBody>
                    <DialogTitle>Notification</DialogTitle>
                    <DialogContent>
                        {message}
                    </DialogContent>
                    <DialogActions>
                        <Button appearance="primary" onClick={onClose}>OK</Button>
                    </DialogActions>
                </DialogBody>
            </DialogSurface>
        </Dialog >
    )
}

export default NotificationComponent