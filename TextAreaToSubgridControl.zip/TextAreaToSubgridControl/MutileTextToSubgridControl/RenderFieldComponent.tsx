import { Input } from '@fluentui/react-components';
import * as React from 'react'
import TextComponent from './components/TextComponent';
import NumberComponent from './components/NumberComponent';
import MutipleComponent from './components/MutipleComponent';
import DateComponent from './components/DateComponent';
import DateTimeComponent from './components/DateTimeComponent';
import BooleanComponent from './components/BooleanComponent';
import LookupComponent from './components/LookupComponent';
import { IInputs } from './generated/ManifestTypes';
import OptionsetComponent from './components/OptionsetComponent';
import { childControlsJson } from './SubgridComponent';

interface RenderFieldComponentProps {
    key: string;
    objControl: childControlsJson | undefined;
    value: string;
    onChange: (e: string) => void;
    context: ComponentFramework.Context<IInputs>;
    isDisable: boolean;
    setVisible?: (v: boolean) => void;
}

function RenderFieldComponent({ key, objControl, value, onChange, context, isDisable, setVisible }: RenderFieldComponentProps) {
    if (objControl?.type == "text") {
        return (
            <TextComponent key={key} value={value} onChange={(data) => onChange(data)} isDisable={isDisable} />
        );
    }
    else if (objControl?.type == "number") {
        return (
            <NumberComponent key={key} value={value} onChange={(data) => onChange(data)} isDisable={isDisable} />
        );
    }
    else if (objControl?.type == "mutiple") {
        return (
            <MutipleComponent key={key} value={value} onChange={(data) => onChange(data)} isDisable={isDisable} />
        );
    }
    else if (objControl?.type == "date") {
        return (
            <DateComponent key={key} value={value} onChange={(data) => onChange(data)} isDisable={isDisable} />
        );
    }
    else if (objControl?.type == "datetime") {
        return (
            <DateTimeComponent key={key} value={value} onChange={(data) => onChange(data)} isDisable={isDisable} />
        );
    }
    else if (objControl?.type == "boolean") {
        return (
            <BooleanComponent key={key} value={value} onChange={(data) => onChange(data)} isDisable={isDisable} />
        );
    }
    else if (objControl?.type == "lookup") {
        return (
            <LookupComponent key={key} value={value} onChange={(data) => onChange(data)} entityName={objControl?.entityType ?? ""} context={context} isDisable={isDisable} setVisible={setVisible} />
        );
    }
    else if (objControl?.type == "optionset") {
        return (
            <OptionsetComponent key={key} value={value} onChange={(data) => onChange(data)} labels={objControl.items ?? []} isDisable={isDisable} />
        );
    }
    else {
        return (
            <Input key={key} style={{ width: "100%" }} value={value} onChange={(_, data) => onChange(data.value)} />
        );
    }
}

export default RenderFieldComponent