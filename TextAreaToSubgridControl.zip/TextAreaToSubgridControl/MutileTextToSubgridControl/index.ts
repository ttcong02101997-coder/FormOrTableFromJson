import { IInputs, IOutputs } from "./generated/ManifestTypes";
import * as React from "react";
import SubgridComponent, { ISubgridComponentProps } from "./SubgridComponent";

export class MutileTextToSubgridControl implements ComponentFramework.ReactControl<IInputs, IOutputs> {
    private notifyOutputChanged: () => void;
    private _fieldProperty: string;
    private _jsonProperty: string;

    constructor() {
        // Empty
    }

    public init(
        context: ComponentFramework.Context<IInputs>,
        notifyOutputChanged: () => void,
        state: ComponentFramework.Dictionary
    ): void {
        this.notifyOutputChanged = notifyOutputChanged;
    }

    public updateView(context: ComponentFramework.Context<IInputs>): React.ReactElement {
        this._fieldProperty = context.parameters.fieldProperty.raw ?? "";
        this._jsonProperty = context.parameters.fieldJson.raw ?? "";

        const props: ISubgridComponentProps = {
            fieldInput: this._fieldProperty,
            fieldJsons: this._jsonProperty,
            context: context,
            callback: (e) => {
                this._fieldProperty = e;
                this.notifyOutputChanged();
            }
        };

        return React.createElement(
            SubgridComponent, props
        );
    }

    public getOutputs(): IOutputs {
        return {
            fieldProperty: this._fieldProperty,
            fieldJson: this._jsonProperty
        };
    }

    public destroy(): void {
        // Add code to cleanup control if necessary
    }
}
