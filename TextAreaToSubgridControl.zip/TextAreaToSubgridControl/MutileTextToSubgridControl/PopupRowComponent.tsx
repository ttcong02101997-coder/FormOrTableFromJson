import * as React from 'react'
import { useEffect, useState } from 'react';
import { childControlsJson, Row } from "./SubgridComponent";
import { Button, DrawerBody, DrawerFooter, DrawerHeader, DrawerHeaderTitle, Field, OverlayDrawer } from '@fluentui/react-components';
import NotificationComponent from './NotificationComponent';
import RenderFieldComponent from './RenderFieldComponent';
import { IInputs } from './generated/ManifestTypes';

interface PopupRowComponentProps {
    visible: boolean;
    itemSelected: Row | null;
    setVisible: (visible: boolean) => void;
    setItemSelected: (item: Row | null) => void;
    callback: (item: Row) => void;
    context: ComponentFramework.Context<IInputs>;
    isDisable: boolean;
    controls: childControlsJson[];
}

function PopupRowComponent({ visible, itemSelected, setItemSelected, setVisible, callback, context, isDisable, controls }: PopupRowComponentProps) {
    const [rowData, setRowData] = useState<Row>({});
    const [messageNoti, setMessageNoti] = useState<string>("");
    const [visibleNoti, setVisibleNoti] = useState<boolean>(false);

    useEffect(() => {
        if (itemSelected != undefined && itemSelected != null) {
            setRowData(itemSelected);
        }
    }, [itemSelected]);

    const onClose = () => {
        setVisible(false);
        setItemSelected(null);
        setRowData({});
    }

    const onDone = () => {
        const isEmpty = Object.getOwnPropertyNames(rowData).every(
            key => rowData[key] == undefined || rowData[key] == null || rowData[key] == ""
        );

        if (isEmpty) {
            setMessageNoti("Please fill in all fields.");
            setVisibleNoti(true);
        }
        else {
            callback(rowData);
            setRowData({});
            setItemSelected(null);
            setVisible(false);
        }
    }

    return (
        <>
            <OverlayDrawer
                open={visible}
                onOpenChange={(_, data) => {
                    if (data.type === "escapeKeyDown") return;
                    if (data.type === "backdropClick") return;
                    setVisible(data.open)
                }}
                position="end"
                size="medium"
                modalType='alert'
                style={{ width: "500px" }}
            >
                <DrawerHeader>
                    <DrawerHeaderTitle>{itemSelected ? "Edit Row" : "Create Row"}</DrawerHeaderTitle>
                </DrawerHeader>
                <DrawerBody>
                    {
                        controls.map((key, index) => {
                            return (
                                <div key={index} style={{ marginBottom: '10px' }}>
                                    <Field label={key.label}>
                                        <RenderFieldComponent
                                            key={key.name}
                                            objControl={controls[index]}
                                            value={rowData[key.name]}
                                            onChange={(value) => {
                                                if (controls[index].type == "datetime")
                                                    setRowData({ ...rowData, [key.name]: value ? new Date(value).toLocaleString() : "" })
                                                else
                                                    setRowData({ ...rowData, [key.name]: value })
                                            }}
                                            context={context}
                                            isDisable={isDisable}
                                            setVisible={setVisible}
                                        />
                                    </Field>
                                </div>
                            )
                        })
                    }
                </DrawerBody>
                <DrawerFooter>
                    <Button appearance="primary" onClick={onDone}>Done</Button>
                    <Button appearance="secondary" onClick={onClose}>Close</Button>
                </DrawerFooter>
            </OverlayDrawer>
            <NotificationComponent message={messageNoti} _visible={visibleNoti} _setVisible={setVisibleNoti} setMessage={setMessageNoti} />
        </>
    )
}

export default PopupRowComponent